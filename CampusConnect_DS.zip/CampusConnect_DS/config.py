import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'campus_connect_ds_secret_key_2026')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_PORT = int(os.getenv('DB_PORT', 3306))
    DB_NAME = os.getenv('DB_NAME', 'campus_connect_db')
    DB_USER = os.getenv('DB_USER', 'campus_ds_user')
    DB_PASSWORD = os.getenv('DB_PASSWORD', 'DsReadOnly@2026')
    PORT = int(os.getenv('PORT', 5000))
