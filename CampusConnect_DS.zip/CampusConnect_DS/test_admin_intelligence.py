import unittest
from app import app

class CampusIntelligenceAdminTestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        self.client = app.test_client()

    def test_01_admin_mcoe_dashboard_two_sections(self):
        # Login as MCOE Admin
        res_login = self.client.post("/login", data={
            "email": "admin@mcoe.edu.in",
            "password": "admin123",
            "login_type": "ADMIN"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        res = self.client.get("/admin/dashboard")
        self.assertEqual(res.status_code, 200)

        # 1. Section 1: Data Analysis exists
        self.assertIn(b"Data Analysis", res.data)
        self.assertIn(b"Students by Department", res.data)
        self.assertIn(b"Student Skills", res.data)
        self.assertIn(b"Complaint Resolution", res.data)
        self.assertIn(b"Lost &amp; Found Items", res.data)
        self.assertIn(b"Summary Statistics", res.data)

        # 2. Section 2: Lost & Found Audit exists
        self.assertIn(b"Lost &amp; Found Audit", res.data)
        self.assertIn(b"Lost Reports", res.data)
        self.assertIn(b"Found Reports", res.data)
        self.assertIn(b"Identified Matches", res.data)
        self.assertIn(b"Identified Match Pairs", res.data)

        # 3. Verify absence of technical buzzwords
        self.assertNotIn(b"Exploratory Data Analysis (EDA)", res.data)
        self.assertNotIn(b"Pandas &amp; Chart.js", res.data)
        self.assertNotIn(b"TF-IDF", res.data)
        self.assertNotIn(b"Cosine Similarity", res.data)

    def test_02_admin_fc_dashboard_two_sections(self):
        # Login as Ferguson College Admin (College 2)
        self.client.get("/logout")
        res_login = self.client.post("/login", data={
            "email": "admin@fc.edu.in",
            "password": "admin123",
            "login_type": "ADMIN"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        res = self.client.get("/admin/dashboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Data Analysis", res.data)
        self.assertIn(b"Lost &amp; Found Audit", res.data)

    def test_03_admin_vit_dashboard_two_sections(self):
        # Login as VIT Admin (College 3)
        self.client.get("/logout")
        res_login = self.client.post("/login", data={
            "email": "admin@vit.edu.in",
            "password": "admin123",
            "login_type": "ADMIN"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        res = self.client.get("/admin/dashboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Data Analysis", res.data)
        self.assertIn(b"Lost &amp; Found Audit", res.data)

    def test_04_student_cannot_access_admin_dashboard(self):
        # Student login
        self.client.get("/logout")
        self.client.post("/login", data={
            "email": "rahul@ait.edu",
            "password": "student123",
            "login_type": "STUDENT"
        })
        res = self.client.get("/admin/dashboard")
        self.assertEqual(res.status_code, 403)

    def test_05_student_features_remain_functional(self):
        self.client.get("/logout")
        self.client.post("/login", data={
            "email": "rahul@ait.edu",
            "password": "student123",
            "login_type": "STUDENT"
        })
        # Study Partners
        res_p = self.client.get("/student/partners")
        self.assertEqual(res_p.status_code, 200)
        self.assertIn(b"Study Partner Recommendations", res_p.data)

        # Events
        res_e = self.client.get("/student/events")
        self.assertEqual(res_e.status_code, 200)
        self.assertIn(b"Recommended Events", res_e.data)

        # Lost & Found
        res_lf = self.client.get("/student/lost-found")
        self.assertEqual(res_lf.status_code, 200)
        self.assertIn(b"Lost &amp; Found Item Matching", res_lf.data)

if __name__ == "__main__":
    unittest.main()
