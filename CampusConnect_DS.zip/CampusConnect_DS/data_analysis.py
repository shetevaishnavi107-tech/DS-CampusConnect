import re
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from database import query_db

def parse_csv_items(text):
    if not text:
        return []
    return [item.strip() for item in str(text).split(",") if item.strip()]

def normalize_dept_name(dept):
    if not dept:
        return "General"
    d = str(dept).strip()
    d_lower = d.lower()
    if d_lower in ["mca", "master of computer applications", "master of computer application"]:
        return "Master of Computer Applications (MCA)"
    elif "artificial intelligence" in d_lower and "data science" in d_lower:
        return "AI & Data Science"
    elif "artificial intelligence" in d_lower or "machine learning" in d_lower:
        return "AI & ML"
    elif "computer science and engineering" in d_lower or "computer engineering" in d_lower or "computer science" in d_lower or "cse" in d_lower:
        return "Computer Science & Engineering"
    elif "information technology" in d_lower or d_lower == "it":
        return "Information Technology"
    elif "electronics" in d_lower:
        return "Electronics & Telecom"
    elif "management" in d_lower:
        return "Management Studies"
    return d

def get_student_profile_intelligence(college_id):
    students = query_db(
        """SELECT id, full_name, department, year, skills, interests 
           FROM users 
           WHERE college_id = %s AND role = 'STUDENT'""",
        (college_id,)
    )
    if not students or len(students) < 2:
        return {
            "status": "insufficient_data",
            "message": "At least 2 registered student profiles are needed to analyze cohort groups.",
            "total": len(students) if students else 0
        }

    corpus = [
        f"{s.get('department') or ''} {s.get('skills') or ''} {s.get('interests') or ''}".strip() or "general student"
        for s in students
    ]
    vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)

    n = len(students)
    k = max(2, min(4, n // 6)) if n >= 6 else 2

    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(tfidf_matrix)

    cohorts = []
    for cluster_id in range(k):
        members = [s for idx, s in enumerate(students) if labels[idx] == cluster_id]
        if not members:
            continue

        skills = []
        for m in members:
            skills.extend([s.title() for s in parse_csv_items(m.get("skills"))])
        top_skills = pd.Series(skills).value_counts().head(4).index.tolist() if skills else []

        interests = []
        for m in members:
            interests.extend([i.title() for i in parse_csv_items(m.get("interests"))])
        top_interests = pd.Series(interests).value_counts().head(3).index.tolist() if interests else []

        dept_series = pd.Series([m.get("department") or "General" for m in members]).value_counts()
        primary_dept = dept_series.index[0] if not dept_series.empty else "General"

        if top_skills:
            group_name = f"Specialization: {', '.join(top_skills[:2])}"
        elif top_interests:
            group_name = f"Focus: {', '.join(top_interests[:2])}"
        else:
            group_name = f"{primary_dept} Cohort"

        cohorts.append({
            "group_id": cluster_id + 1,
            "name": group_name,
            "student_count": len(members),
            "percentage": round((len(members) / n) * 100),
            "top_skills": top_skills,
            "top_interests": top_interests,
            "primary_department": primary_dept,
            "sample_students": [m["full_name"] for m in members[:3]]
        })

    cohorts.sort(key=lambda x: x["student_count"], reverse=True)

    return {
        "status": "success",
        "total": n,
        "cohort_count": len(cohorts),
        "cohorts": cohorts
    }

def get_grievance_intelligence(college_id):
    complaints = query_db(
        """SELECT id, category, subject, description, priority, status, created_at 
           FROM complaints 
           WHERE college_id = %s 
           ORDER BY created_at DESC""",
        (college_id,)
    )
    if not complaints:
        return {
            "status": "insufficient_data",
            "message": "No student grievances currently recorded for this campus.",
            "total": 0
        }

    df = pd.DataFrame(complaints)
    total = len(df)
    resolved_count = int((df["status"] == "RESOLVED").sum())
    overall_res_rate = round((resolved_count / total) * 100, 1)

    texts = [f"{c['category']} {c['subject']} {c.get('description') or ''}" for c in complaints]
    
    # TF-IDF keyword extraction
    vectorizer = TfidfVectorizer(stop_words="english", min_df=1, ngram_range=(1, 2))
    tfidf_matrix = vectorizer.fit_transform(texts)

    # Cluster complaints into recurring issue themes if at least 3 complaints exist
    k = max(1, min(3, total // 2)) if total >= 3 else 1
    if total >= 3 and k > 1:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(tfidf_matrix)
    else:
        labels = np.zeros(total, dtype=int)

    themes = []
    for cluster_id in range(k):
        group = [c for idx, c in enumerate(complaints) if labels[idx] == cluster_id]
        if not group:
            continue

        g_texts = [texts[idx] for idx, c in enumerate(complaints) if labels[idx] == cluster_id]
        g_vec = TfidfVectorizer(stop_words="english", min_df=1)
        g_matrix = g_vec.fit_transform(g_texts)
        mean_weights = g_matrix.mean(axis=0).A1
        top_terms = [g_vec.get_feature_names_out()[idx].title() for idx in mean_weights.argsort()[::-1][:3]]

        theme_cat = pd.Series([c["category"] for c in group]).value_counts().index[0]
        g_resolved = sum(1 for c in group if c["status"] == "RESOLVED")
        g_rate = round((g_resolved / len(group)) * 100)

        theme_title = ", ".join(top_terms[:2]) if top_terms else theme_cat

        themes.append({
            "theme_id": cluster_id + 1,
            "title": f"Pattern: {theme_title}",
            "primary_category": theme_cat,
            "count": len(group),
            "percentage": round((len(group) / total) * 100),
            "resolution_rate": g_rate,
            "key_terms": top_terms,
            "sample_subjects": [c["subject"] for c in group[:3]]
        })

    themes.sort(key=lambda x: x["count"], reverse=True)

    return {
        "status": "success",
        "total": total,
        "resolution_rate": overall_res_rate,
        "themes": themes
    }

def get_event_intelligence(college_id):
    events = query_db(
        """SELECT id, title, description, venue, event_date, department 
           FROM events 
           WHERE college_id = %s 
           ORDER BY event_date ASC""",
        (college_id,)
    )
    if not events:
        return {
            "status": "insufficient_data",
            "message": "No scheduled campus events found for this college.",
            "total": 0
        }

    df = pd.DataFrame(events)
    total = len(df)

    dept_counts = df["department"].replace("", "General").value_counts().head(4).to_dict()
    venue_counts = df["venue"].replace("", "Campus").value_counts().head(4).to_dict()
    top_venue = list(venue_counts.keys())[0] if venue_counts else "Campus"

    # Extract dominant event themes using TF-IDF
    texts = [f"{r['title']} {r['description'] or ''} {r['department'] or ''}" for _, r in df.iterrows()]
    vec = TfidfVectorizer(stop_words="english", min_df=1, ngram_range=(1, 2))
    tfidf_matrix = vec.fit_transform(texts)
    mean_weights = tfidf_matrix.mean(axis=0).A1
    top_topics = [vec.get_feature_names_out()[idx].title() for idx in mean_weights.argsort()[::-1][:5]]

    return {
        "status": "success",
        "total": total,
        "top_venue": top_venue,
        "top_departments": dept_counts,
        "top_venues": venue_counts,
        "dominant_themes": top_topics
    }

def get_resource_intelligence(college_id):
    resources = query_db(
        """SELECT id, title, subject, department, semester, resource_type 
           FROM resources 
           WHERE college_id = %s""",
        (college_id,)
    )
    if not resources:
        return {
            "status": "insufficient_data",
            "message": "No uploaded study resources found for this college.",
            "total": 0
        }

    df = pd.DataFrame(resources)
    total = len(df)

    type_counts = df["resource_type"].replace("", "NOTES").value_counts().to_dict()
    subject_counts = df["subject"].dropna().replace("", "General").value_counts().head(5).to_dict()
    top_subject = list(subject_counts.keys())[0] if subject_counts else None
    top_subject_cnt = subject_counts[top_subject] if top_subject else 0

    # TF-IDF keyword extraction across study titles and subjects
    texts = [f"{r['title']} {r['subject'] or ''} {r['resource_type'] or ''}" for _, r in df.iterrows()]
    vec = TfidfVectorizer(stop_words="english", min_df=1, ngram_range=(1, 2))
    tfidf_matrix = vec.fit_transform(texts)
    mean_weights = tfidf_matrix.mean(axis=0).A1
    top_topics = [vec.get_feature_names_out()[idx].title() for idx in mean_weights.argsort()[::-1][:5]]

    return {
        "status": "success",
        "total": total,
        "top_subject": top_subject,
        "top_subject_count": top_subject_cnt,
        "subject_distribution": subject_counts,
        "type_distribution": type_counts,
        "top_topics": top_topics
    }

def get_notice_intelligence(college_id):
    notices = query_db(
        """SELECT id, title, content, category, target_department, created_at 
           FROM notices 
           WHERE college_id = %s 
           ORDER BY created_at DESC""",
        (college_id,)
    )
    if not notices:
        return {
            "status": "insufficient_data",
            "message": "No published notices found for this college.",
            "total": 0
        }

    df = pd.DataFrame(notices)
    total = len(df)

    cat_counts = df["category"].replace("", "General").value_counts().to_dict()
    dept_counts = df["target_department"].replace("", "ALL").value_counts().head(4).to_dict()
    top_cat = list(cat_counts.keys())[0] if cat_counts else "General"
    top_cat_cnt = cat_counts[top_cat] if top_cat else 0

    # TF-IDF keyword extraction on notice titles and content
    texts = [f"{r['title']} {r['content'] or ''}" for _, r in df.iterrows()]
    vec = TfidfVectorizer(stop_words="english", min_df=1, ngram_range=(1, 2))
    tfidf_matrix = vec.fit_transform(texts)
    mean_weights = tfidf_matrix.mean(axis=0).A1
    top_keywords = [vec.get_feature_names_out()[idx].title() for idx in mean_weights.argsort()[::-1][:5]]

    return {
        "status": "success",
        "total": total,
        "top_category": top_cat,
        "top_category_count": top_cat_cnt,
        "category_distribution": cat_counts,
        "department_distribution": dept_counts,
        "important_terms": top_keywords
    }

def get_campus_intelligence(college_id):
    students_info = get_student_profile_intelligence(college_id)
    grievance_info = get_grievance_intelligence(college_id)
    event_info = get_event_intelligence(college_id)
    resource_info = get_resource_intelligence(college_id)
    notice_info = get_notice_intelligence(college_id)

    # Dynamic Automatic College Insights
    insights = []

    # Student insight
    if students_info.get("status") == "success" and students_info.get("cohorts"):
        top_cohort = students_info["cohorts"][0]
        insights.append(
            f"Student Specialization: Largest cohort is '{top_cohort['name']}' representing {top_cohort['percentage']}% of students ({top_cohort['student_count']} members)."
        )

    # Grievance insight
    if grievance_info.get("status") == "success" and grievance_info.get("themes"):
        top_theme = grievance_info["themes"][0]
        insights.append(
            f"Grievance Pattern: '{top_theme['title']}' accounts for {top_theme['count']} complaints ({top_theme['resolution_rate']}% resolution rate)."
        )
    elif grievance_info.get("status") == "insufficient_data":
        insights.append("Grievance Status: No complaints recorded for this college.")

    # Event insight
    if event_info.get("status") == "success" and event_info.get("dominant_themes"):
        insights.append(
            f"Event Themes: {event_info['total']} campus events scheduled with dominant focus on {', '.join(event_info['dominant_themes'][:2])} (primary venue: {event_info['top_venue']})."
        )
    elif event_info.get("status") == "insufficient_data":
        insights.append("Campus Events: No scheduled student activities currently published.")

    # Resource insight
    if resource_info.get("status") == "success" and resource_info.get("top_subject"):
        insights.append(
            f"Study Resources: '{resource_info['top_subject']}' has the highest volume of study material ({resource_info['top_subject_count']} files)."
        )
    elif resource_info.get("status") == "insufficient_data":
        insights.append("Study Resources: No academic resources uploaded yet.")

    # Notice insight
    if notice_info.get("status") == "success" and notice_info.get("top_category"):
        insights.append(
            f"Notice Communication: '{notice_info['top_category']}' is the most active broadcast category with key themes in {', '.join(notice_info['important_terms'][:2])}."
        )
    elif notice_info.get("status") == "insufficient_data":
        insights.append("Announcements: No official notices published yet.")

    return {
        "students": students_info,
        "grievances": grievance_info,
        "events": event_info,
        "resources": resource_info,
        "notices": notice_info,
        "insights": insights
    }

def get_admin_eda_data(college_id):
    # Provides visual chart datasets for the detailed analysis view
    intel = get_campus_intelligence(college_id)
    users = query_db("SELECT id, department, year, skills, interests, role FROM users WHERE college_id = %s", (college_id,))
    complaints = query_db("SELECT id, category, priority, status FROM complaints WHERE college_id = %s", (college_id,))
    lost_found = query_db("SELECT id, type, status FROM lost_found WHERE college_id = %s", (college_id,))

    df_users = pd.DataFrame(users) if users else pd.DataFrame(columns=["department", "year", "skills", "interests", "role"])
    df_complaints = pd.DataFrame(complaints) if complaints else pd.DataFrame(columns=["category", "priority", "status"])
    df_lost_found = pd.DataFrame(lost_found) if lost_found else pd.DataFrame(columns=["type", "status"])

    df_students = df_users[df_users["role"] == "STUDENT"] if not df_users.empty and "role" in df_users.columns else pd.DataFrame()

    if not df_students.empty:
        dept_series = df_students["department"].dropna().apply(normalize_dept_name)
        dept_counts = dept_series.value_counts().head(6).to_dict()
        year_counts = df_students["year"].dropna().replace("", "General").value_counts().to_dict()
    else:
        dept_counts = {}
        year_counts = {}

    all_skills = []
    all_interests = []
    if not df_students.empty:
        for val in df_students["skills"].dropna():
            for item in str(val).split(","):
                cleaned = item.strip().title()
                if cleaned:
                    all_skills.append(cleaned)
        for val in df_students["interests"].dropna():
            for item in str(val).split(","):
                cleaned = item.strip().title()
                if cleaned:
                    all_interests.append(cleaned)

    top_skills = pd.Series(all_skills).value_counts().head(8).to_dict() if all_skills else {}
    top_interests = pd.Series(all_interests).value_counts().head(6).to_dict() if all_interests else {}

    complaint_status = df_complaints["status"].value_counts().to_dict() if not df_complaints.empty else {}
    complaint_category = df_complaints["category"].value_counts().head(6).to_dict() if not df_complaints.empty else {}

    lf_types = df_lost_found["type"].value_counts().to_dict() if not df_lost_found.empty else {}

    res_rate = 0.0
    if not df_complaints.empty:
        total_c = len(df_complaints)
        resolved_c = int((df_complaints["status"] == "RESOLVED").sum())
        res_rate = round((resolved_c / total_c) * 100, 1) if total_c > 0 else 0.0

    # Key highlight metrics for interesting presentation
    top_dept_name = list(dept_counts.keys())[0] if dept_counts else "General"
    top_dept_count = list(dept_counts.values())[0] if dept_counts else 0
    top_skill_name = list(top_skills.keys())[0] if top_skills else "None"
    top_skill_count = list(top_skills.values())[0] if top_skills else 0
    top_interest_name = list(top_interests.keys())[0] if top_interests else "None"
    top_interest_count = list(top_interests.values())[0] if top_interests else 0

    return {
        "summary": {
            "total_students": len(df_students),
            "total_events": intel["events"]["total"] if intel["events"].get("status") == "success" else 0,
            "total_complaints": len(df_complaints),
            "total_lost_found": len(df_lost_found),
            "total_resources": intel["resources"]["total"] if intel["resources"].get("status") == "success" else 0,
            "total_notices": intel["notices"]["total"] if intel["notices"].get("status") == "success" else 0,
            "complaint_resolution_rate": res_rate,
            "top_department": top_dept_name,
            "top_department_count": top_dept_count,
            "top_skill": top_skill_name,
            "top_skill_count": top_skill_count,
            "top_interest": top_interest_name,
            "top_interest_count": top_interest_count
        },
        "insights": intel["insights"],
        "intelligence": intel,
        "charts": {
            "departments": {"labels": list(dept_counts.keys()), "values": [int(v) for v in dept_counts.values()]},
            "years": {"labels": list(year_counts.keys()), "values": [int(v) for v in year_counts.values()]},
            "skills": {"labels": list(top_skills.keys()), "values": [int(v) for v in top_skills.values()]},
            "interests": {"labels": list(top_interests.keys()), "values": [int(v) for v in top_interests.values()]},
            "complaint_status": {"labels": list(complaint_status.keys()), "values": [int(v) for v in complaint_status.values()]},
            "complaint_category": {"labels": list(complaint_category.keys()), "values": [int(v) for v in complaint_category.values()]},
            "lost_found_types": {"labels": list(lf_types.keys()), "values": [int(v) for v in lf_types.values()]}
        }
    }
