import unittest
from app import app
from database import query_db

class CampusConnectDSUpdatedTestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        self.client = app.test_client()

    def test_01_unauthenticated_redirect(self):
        res = self.client.get("/")
        self.assertEqual(res.status_code, 302)
        self.assertIn("/login", res.headers["Location"])

    def test_02_separate_student_and_admin_login(self):
        # 1. Try to login with Admin credentials on Student login -> MUST FAIL
        res_fail1 = self.client.post("/login", data={
            "email": "admin@mcoe.edu.in",
            "password": "admin123",
            "login_type": "STUDENT"
        })
        self.assertIn(b"This is an Administrator account. Please use Admin Login.", res_fail1.data)

        # 2. Try to login with Student credentials on Admin login -> MUST FAIL
        res_fail2 = self.client.post("/login", data={
            "email": "rahul@ait.edu",
            "password": "student123",
            "login_type": "ADMIN"
        })
        self.assertIn(b"This is a Student account. Please use Student Login.", res_fail2.data)

        # 3. Valid Student Login -> MUST SUCCEED
        res_ok_student = self.client.post("/login", data={
            "email": "rahul@ait.edu",
            "password": "student123",
            "login_type": "STUDENT"
        }, follow_redirects=True)
        self.assertEqual(res_ok_student.status_code, 200)
        self.assertIn(b"Student Portal", res_ok_student.data)

    def test_03_clean_student_dashboard_no_jargon(self):
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        res = self.client.get("/student/dashboard")
        self.assertEqual(res.status_code, 200)

        # Confirm technical jargon is NOT visible
        self.assertNotIn(b"Assigned Cluster", res.data)
        self.assertNotIn(b"k=3", res.data)
        self.assertNotIn(b"k=5", res.data)
        self.assertNotIn(b"TF-IDF Vector", res.data)
        self.assertNotIn(b"NLP Matching", res.data)

        # Confirm clean UI elements exist
        self.assertIn(b"Smart Partner Matching", res.data)
        self.assertIn(b"Recommended Events", res.data)
        self.assertIn(b"Why recommended", res.data)

    def test_04_study_partner_reasons_and_filters(self):
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        res = self.client.get("/student/partners")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Study Partner Recommendations", res.data)
        self.assertIn(b"Why recommended?", res.data)
        # Check no cluster number on cards
        self.assertNotIn(b"Cluster #", res.data)

        # Test department filter
        res_f = self.client.get("/student/partners?dept=Master+of+Computer+Applications")
        self.assertEqual(res_f.status_code, 200)

        # Test empty filter result
        res_empty = self.client.get("/student/partners?skill=NonExistentSkillXYZ123")
        self.assertEqual(res_empty.status_code, 200)
        self.assertIn(b"No suitable study partners found", res_empty.data)

    def test_05_event_reasons_and_filters(self):
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        res = self.client.get("/student/events")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Recommended Events", res.data)
        self.assertIn(b"Similarity:", res.data)
        self.assertNotIn(b"TF-IDF Score", res.data)
        self.assertIn(b"Why recommended?", res.data)

        # Verify interest prioritization: set interests to Cloud Computing and verify it tops recommendations
        self.client.post("/student/profile", data={
            "skills": "Java, Python",
            "interests": "Cloud Computing",
            "bio": "Test bio"
        })
        res_pri = self.client.get("/student/events")
        self.assertEqual(res_pri.status_code, 200)
        self.assertIn(b"Cloud Computing", res_pri.data)
        self.assertIn(b"Matches your selected interest in Cloud Computing", res_pri.data)

        # Empty event filter test
        res_e = self.client.get("/student/events?q=NonExistentEventWord999")
        self.assertEqual(res_e.status_code, 200)
        self.assertIn(b"No highly relevant events found at the moment", res_e.data)

    def test_06_lost_found_matching_reasons(self):
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        res = self.client.get("/student/lost-found?q=watch")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Lost &amp; Found Item Matching", res.data)
        self.assertIn(b"Similarity:", res.data)

    def test_07_profile_update_and_security(self):
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        # 1. View profile
        res_get = self.client.get("/student/profile")
        self.assertEqual(res_get.status_code, 200)
        self.assertIn(b"My Student Profile", res_get.data)

        # 2. Update skills and interests
        new_skills = "Java, MySQL, HTML, CSS, JavaScript, Spring Boot, Python"
        res_post = self.client.post("/student/profile", data={
            "skills": new_skills,
            "interests": "Web Development, Open Source, Cricket, Data Science",
            "bio": "2nd year MCA student enthusiastic about full-stack Java and database design."
        }, follow_redirects=True)
        self.assertEqual(res_post.status_code, 200)
        self.assertIn(b"Profile updated successfully", res_post.data)

        # 3. Verify in database: skills updated, role/college_id strictly untouched
        u = query_db("SELECT id, role, college_id, email, skills FROM users WHERE email = %s", ("rahul@ait.edu",), one=True)
        self.assertEqual(u["role"], "STUDENT")
        self.assertEqual(u["college_id"], 1)
        self.assertEqual(u["email"], "rahul@ait.edu")
        self.assertEqual(u["skills"], new_skills)

    def test_08_admin_insights_and_security(self):
        # 1. Admin login
        self.client.get("/logout")
        res = self.client.post("/login", data={
            "email": "admin@mcoe.edu.in",
            "password": "admin123",
            "login_type": "ADMIN"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Administrator Dashboard", res.data)
        self.assertIn(b"College Insights", res.data)

        # 2. Student trying to access admin dashboard -> 403 Forbidden
        self.client.get("/logout")
        self.client.post("/login", data={"email": "rahul@ait.edu", "password": "student123", "login_type": "STUDENT"})
        res_sec = self.client.get("/admin/analysis")
        self.assertEqual(res_sec.status_code, 403)

if __name__ == "__main__":
    unittest.main()
