﻿import hashlib
from functools import wraps
from flask import session, redirect, url_for, abort, flash
from database import query_db

def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def authenticate(email, password, required_role=None):
    sql = """
        SELECT u.*, c.name AS college_name, c.code AS college_code 
        FROM users u 
        LEFT JOIN colleges c ON u.college_id = c.id 
        WHERE u.email = %s
    """
    user = query_db(sql, (email.strip().lower(),), one=True)
    if not user:
        return None, "Invalid email or password."

    hashed = hash_password(password)
    if user["password_hash"].lower() != hashed.lower():
        return None, "Invalid email or password."

    # Verify matching role for separate student and admin login
    if required_role and user["role"].upper() != required_role.upper():
        if required_role.upper() == "STUDENT":
            return None, "This is an Administrator account. Please use Admin Login."
        else:
            return None, "This is a Student account. Please use Student Login."

    user.pop("password_hash", None)
    return user, None

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in as Administrator to continue.", "warning")
            return redirect(url_for("login"))
        if session.get("role") != "ADMIN":
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def student_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in as Student to continue.", "warning")
            return redirect(url_for("login"))
        if session.get("role") != "STUDENT":
            abort(403)
        return f(*args, **kwargs)
    return decorated_function
