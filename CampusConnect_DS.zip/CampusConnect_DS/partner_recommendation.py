﻿import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity
from database import query_db

def parse_items(text):
    if not text:
        return []
    return [item.strip() for item in str(text).split(",") if item.strip()]

def get_recommendation_reasons(user, candidate, user_req, cand_req, is_same_cluster):
    reasons = []

    # Check shared skills
    user_skills = {s.lower(): s for s in parse_items(user.get("skills"))}
    cand_skills = {s.lower(): s for s in parse_items(candidate.get("skills"))}
    shared_skills = [cand_skills[k] for k in cand_skills if k in user_skills]
    if shared_skills:
        reasons.append(f"Shared skills: {', '.join(shared_skills[:2])}")

    # Check common interests
    user_interests = {i.lower(): i for i in parse_items(user.get("interests"))}
    cand_interests = {i.lower(): i for i in parse_items(candidate.get("interests"))}
    shared_interests = [cand_interests[k] for k in cand_interests if k in user_interests]
    if shared_interests:
        reasons.append(f"Common interest: {', '.join(shared_interests[:2])}")

    # Check department
    if user.get("department") and candidate.get("department") and user["department"].strip().lower() == candidate["department"].strip().lower():
        reasons.append(f"Same department: {candidate['department']}")

    # Check project domain preference
    user_dom = (user_req.get("project_domain") or "").strip().lower() if user_req else ""
    cand_dom = (cand_req.get("project_domain") or "").strip().lower() if cand_req else ""
    if user_dom and cand_dom and user_dom == cand_dom:
        reasons.append(f"Similar project preference: {cand_req['project_domain']}")
    elif cand_dom:
        reasons.append(f"Project focus: {cand_req['project_domain']}")

    # Check academic year
    if user.get("year") and candidate.get("year") and user["year"] == candidate["year"]:
        reasons.append(f"Same academic year: {candidate['year']}")

    if is_same_cluster and len(reasons) < 2:
        reasons.append("High profile compatibility")

    return reasons[:3]

def recommend_study_partners(college_id, current_user_id, department_filter=None, skill_filter=None, domain_filter=None):
    students = query_db(
        """SELECT id, full_name, email, department, year, skills, interests 
           FROM users 
           WHERE college_id = %s AND role = 'STUDENT'""",
        (college_id,)
    )

    if not students:
        return {"recommendations": [], "departments": [], "domains": []}

    reqs = query_db(
        """SELECT student_id, project_domain, skills_needed, title 
           FROM partner_requests 
           WHERE college_id = %s AND status = 'OPEN'""",
        (college_id,)
    )
    reqs_by_student = {r["student_id"]: r for r in reqs}

    user_idx = next((i for i, s in enumerate(students) if s["id"] == current_user_id), None)
    current_user = students[user_idx] if user_idx is not None else {}
    current_user_req = reqs_by_student.get(current_user_id)

    corpus = [
        f"{s.get('department') or ''} {s.get('skills') or ''} {s.get('interests') or ''}".strip() or "student"
        for s in students
    ]

    vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)

    n_students = len(students)
    k = max(1, min(3, n_students // 2)) if n_students >= 2 else 1

    if n_students >= 2 and k > 1:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(tfidf_matrix)
    else:
        labels = np.zeros(n_students, dtype=int)

    for i, s in enumerate(students):
        s["cluster_id"] = int(labels[i])

    user_cluster = current_user.get("cluster_id")
    ref_vec = tfidf_matrix[user_idx] if user_idx is not None else tfidf_matrix[0]
    sim_scores = cosine_similarity(ref_vec, tfidf_matrix).flatten()

    all_departments = sorted(list({s["department"] for s in students if s.get("department")}))
    all_domains = sorted(list({r["project_domain"] for r in reqs if r.get("project_domain")}))

    results = []
    for i, s in enumerate(students):
        if s["id"] == current_user_id:
            continue

        cand_req = reqs_by_student.get(s["id"])
        cand_domain = cand_req.get("project_domain") if cand_req else None

        if department_filter and s.get("department") != department_filter:
            continue
        if skill_filter and skill_filter.lower() not in (s.get("skills") or "").lower():
            continue
        if domain_filter and cand_domain != domain_filter:
            continue

        score = float(sim_scores[i])
        is_same = (s["cluster_id"] == user_cluster) if user_cluster is not None else False
        
        reasons = get_recommendation_reasons(current_user, s, current_user_req, cand_req, is_same)

        results.append({
            "id": s["id"],
            "full_name": s["full_name"],
            "email": s["email"],
            "department": s["department"] or "General",
            "year": s["year"] or "N/A",
            "skills": s["skills"] or "Not specified",
            "interests": s["interests"] or "Not specified",
            "project_domain": cand_domain or "General Collaboration",
            "match_percent": max(round(score * 100), 15 if is_same else 10),
            "reasons": reasons,
            "is_same_cluster": is_same,
            "similarity_score": round(score, 4)
        })

    results.sort(key=lambda x: (x["is_same_cluster"], x["similarity_score"]), reverse=True)

    return {
        "recommendations": results,
        "departments": all_departments,
        "domains": all_domains
    }

def get_cluster_insights(college_id):
    students = query_db(
        """SELECT id, full_name, email, department, year, skills, interests 
           FROM users 
           WHERE college_id = %s AND role = 'STUDENT'""",
        (college_id,)
    )
    if not students:
        return {"clusters": {}, "k": 0, "total": 0}

    corpus = [
        f"{s.get('department') or ''} {s.get('skills') or ''} {s.get('interests') or ''}".strip() or "student"
        for s in students
    ]
    vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)
    k = max(1, min(3, len(students) // 2)) if len(students) >= 2 else 1

    if len(students) >= 2 and k > 1:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(tfidf_matrix)
    else:
        labels = np.zeros(len(students), dtype=int)

    clusters = {}
    for i, s in enumerate(students):
        c_id = int(labels[i])
        if c_id not in clusters:
            clusters[c_id] = []
        clusters[c_id].append({
            "id": s["id"],
            "full_name": s["full_name"],
            "department": s["department"],
            "year": s["year"],
            "skills": s["skills"]
        })

    return {"clusters": clusters, "k": k, "total": len(students)}
