import unittest
from app import app

class LostFoundPrivacyTestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        self.client = app.test_client()

    def test_01_lost_owner_sees_match(self):
        # 1. Login as Tareeka Rane (user_id = 111, who reported lost earphone id 28)
        res_login = self.client.post("/login", data={
            "email": "tareeka@mcoe.edu.in",
            "password": "123456",
            "login_type": "STUDENT"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        # Dashboard should display the possible match card
        res_dash = self.client.get("/student/dashboard")
        self.assertEqual(res_dash.status_code, 200)
        self.assertIn(b"Possible Match Found for Your Reported Item!", res_dash.data)
        self.assertIn(b"earphone", res_dash.data)

        # Lost & Found page should display the match card with thumbnail and similarity
        res_lf = self.client.get("/student/lost-found")
        self.assertEqual(res_lf.status_code, 200)
        self.assertIn(b"Possible Match", res_lf.data)
        self.assertIn(b"Similarity", res_lf.data)
        self.assertIn(b"Reported Lost", res_lf.data)
        self.assertIn(b"Reported Found", res_lf.data)

    def test_02_found_owner_sees_match(self):
        # 2. Login as Vaishnavi Shete (user_id = 34, who reported found earphone id 29)
        self.client.get("/logout")
        res_login = self.client.post("/login", data={
            "email": "vaish@mcoe.edu.in",
            "password": "123456",
            "login_type": "STUDENT"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        # Dashboard should also display the match
        res_dash = self.client.get("/student/dashboard")
        self.assertEqual(res_dash.status_code, 200)
        self.assertIn(b"Possible Match Found for Your Reported Item!", res_dash.data)
        self.assertIn(b"earphone", res_dash.data)

        # Lost & Found page should display the match
        res_lf = self.client.get("/student/lost-found")
        self.assertEqual(res_lf.status_code, 200)
        self.assertIn(b"Possible Match", res_lf.data)

    def test_03_other_students_do_not_see_match(self):
        # 3. Login as Rahul Sharma (user_id = 37, neither lost nor found owner of this item)
        self.client.get("/logout")
        res_login = self.client.post("/login", data={
            "email": "rahul@ait.edu",
            "password": "student123",
            "login_type": "STUDENT"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        # Rahul's dashboard should NOT show the match alert
        res_dash = self.client.get("/student/dashboard")
        self.assertEqual(res_dash.status_code, 200)
        self.assertNotIn(b"Possible Match Found for Your Reported Item!", res_dash.data)

        # Rahul's lost & found page should show 0 matches
        res_lf = self.client.get("/student/lost-found")
        self.assertEqual(res_lf.status_code, 200)
        self.assertIn(b"0 Active Matches", res_lf.data)
        self.assertIn(b"No active matches for your reported items.", res_lf.data)

    def test_04_admin_can_audit_matches(self):
        # 4. Admin login
        self.client.get("/logout")
        res_login = self.client.post("/login", data={
            "email": "admin@mcoe.edu.in",
            "password": "admin123",
            "login_type": "ADMIN"
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)

        # Admin lost-found audit page
        res_audit = self.client.get("/admin/lost-found-insights")
        self.assertEqual(res_audit.status_code, 200)
        self.assertIn(b"Identified Match Pairs", res_audit.data)
        self.assertIn(b"earphone", res_audit.data)

if __name__ == "__main__":
    unittest.main()
