import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, send_from_directory
from config import Config
from auth import authenticate, login_required, admin_required, student_required
from partner_recommendation import recommend_study_partners, get_cluster_insights
from event_recommendation import recommend_events
from lost_found_matching import match_lost_and_found, search_matching_items
from data_analysis import get_admin_eda_data, get_campus_intelligence
from database import query_db

app = Flask(__name__)
app.config.from_object(Config)

@app.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("login"))
    if session.get("role") == "ADMIN":
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("student_dashboard"))

@app.route("/login", methods=["GET", "POST"])
def login():
    selected_role = request.args.get("role", "STUDENT").upper()
    if selected_role not in ["STUDENT", "ADMIN"]:
        selected_role = "STUDENT"

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        role_type = request.form.get("login_type", "STUDENT").strip().upper()

        user, err_msg = authenticate(email, password, required_role=role_type)
        if user:
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["email"] = user["email"]
            session["role"] = user["role"]
            session["college_id"] = user["college_id"]
            session["college_name"] = user.get("college_name") or f"College #{user['college_id']}"
            session["department"] = user.get("department") or "General"

            flash(f"Welcome back, {user['full_name']}!", "success")
            if user["role"] == "ADMIN":
                return redirect(url_for("admin_dashboard"))
            return redirect(url_for("student_dashboard"))
        else:
            flash(err_msg or "Invalid email or password.", "danger")
            if "Please use Admin Login" in (err_msg or ""):
                selected_role = "ADMIN"
            elif "Please use Student Login" in (err_msg or ""):
                selected_role = "STUDENT"
            else:
                selected_role = role_type

    return render_template("login.html", active_role=selected_role)

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out safely.", "info")
    return redirect(url_for("login"))

@app.route("/student/dashboard")
@student_required
def student_dashboard():
    college_id = session["college_id"]
    user_id = session["user_id"]

    partners_data = recommend_study_partners(college_id, user_id)
    top_partners = partners_data["recommendations"][:3]

    events_data = recommend_events(college_id, user_id)
    top_events = events_data["events"][:3]

    lf_data = match_lost_and_found(college_id, user_id=user_id)

    return render_template(
        "student_dashboard.html",
        top_partners=top_partners,
        top_events=top_events,
        user_matches=lf_data["matched_pairs"],
        lf_matches_count=len(lf_data["matched_pairs"])
    )

@app.route("/student/profile", methods=["GET", "POST"])
@student_required
def student_profile():
    user_id = session["user_id"]
    
    if request.method == "POST":
        skills = request.form.get("skills", "").strip()
        interests = request.form.get("interests", "").strip()
        bio = request.form.get("bio", "").strip()

        # Update allowed recommendation fields safely
        query_db(
            "UPDATE users SET skills = %s, interests = %s, bio = %s WHERE id = %s",
            (skills, interests, bio, user_id)
        )
        flash("Profile updated successfully! Recommendations have been updated with your new skills.", "success")
        return redirect(url_for("student_profile"))

    user = query_db(
        """SELECT u.*, c.name AS college_name 
           FROM users u 
           LEFT JOIN colleges c ON u.college_id = c.id 
           WHERE u.id = %s""",
        (user_id,),
        one=True
    )
    return render_template("profile.html", user=user)

@app.route("/student/partners")
@student_required
def student_partners():
    college_id = session["college_id"]
    user_id = session["user_id"]

    dept_filter = request.args.get("dept", "").strip()
    skill_filter = request.args.get("skill", "").strip()
    domain_filter = request.args.get("domain", "").strip()
    is_refresh = request.args.get("refresh") == "1"

    if is_refresh:
        flash("Study partner recommendations refreshed.", "info")

    data = recommend_study_partners(
        college_id,
        user_id,
        department_filter=dept_filter if dept_filter else None,
        skill_filter=skill_filter if skill_filter else None,
        domain_filter=domain_filter if domain_filter else None
    )

    return render_template(
        "partner.html",
        recommendations=data["recommendations"],
        departments=data["departments"],
        domains=data["domains"],
        selected_dept=dept_filter,
        selected_skill=skill_filter,
        selected_domain=domain_filter
    )

@app.route("/student/events")
@student_required
def student_events():
    college_id = session["college_id"]
    user_id = session["user_id"]

    dept_filter = request.args.get("dept", "").strip()
    keyword = request.args.get("q", "").strip()
    is_refresh = request.args.get("refresh") == "1"

    if is_refresh:
        flash("Event recommendations refreshed.", "info")

    data = recommend_events(
        college_id,
        user_id,
        dept_filter=dept_filter if dept_filter else None,
        keyword_filter=keyword if keyword else None
    )

    return render_template(
        "events.html",
        events=data["events"],
        departments=data["departments"],
        selected_dept=dept_filter,
        search_q=keyword
    )

@app.route("/student/lost-found")
@student_required
def student_lost_found():
    college_id = session["college_id"]
    search_q = request.args.get("q", "").strip()
    target_type = request.args.get("type", "FOUND").strip().upper()
    is_refresh = request.args.get("refresh") == "1"

    if is_refresh:
        flash("Lost and found matches refreshed.", "info")

    user_id = session["user_id"]
    data = match_lost_and_found(college_id, user_id=user_id)
    search_results = []
    if search_q:
        search_results = search_matching_items(college_id, search_q, target_type)

    return render_template(
        "lost_found.html",
        matched_pairs=data["matched_pairs"],
        lost_count=data["lost_count"],
        found_count=data["found_count"],
        search_results=search_results,
        search_q=search_q,
        target_type=target_type
    )

@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    college_id = session["college_id"]
    eda = get_admin_eda_data(college_id)
    lf_data = match_lost_and_found(college_id, threshold=0.20)
    return render_template(
        "admin_dashboard.html",
        eda=eda,
        lf_data=lf_data
    )

@app.route("/admin/analysis")
@admin_required
def admin_analysis():
    college_id = session["college_id"]
    eda = get_admin_eda_data(college_id)
    return render_template("data_analysis.html", eda=eda)

@app.route("/admin/partner-insights")
@admin_required
def admin_partner_insights():
    college_id = session["college_id"]
    insights = get_cluster_insights(college_id)
    return render_template("admin_partners.html", insights=insights)

@app.route("/admin/lost-found-insights")
@admin_required
def admin_lost_found_insights():
    college_id = session["college_id"]
    data = match_lost_and_found(college_id, threshold=0.20)
    return render_template("admin_lost_found.html", data=data)

@app.route("/uploads/<path:filename>")
def serve_uploads(filename):
    search_dirs = [
        r"C:\Users\dhiraj12\.gemini\antigravity\scratch\CampusConnect\web\uploads",
        r"C:\Users\dhiraj12\Desktop\CampusConnect\CampusConnect\web\uploads",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
    ]
    for d in search_dirs:
        file_path = os.path.join(d, filename)
        if os.path.exists(file_path):
            return send_from_directory(d, filename)
    abort(404)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=Config.PORT, debug=True)
