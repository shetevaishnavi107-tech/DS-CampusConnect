﻿# CampusConnect_DS — Data Science Platform

Standalone Python Data Science web application developed for the CampusConnect ecosystem. Operates on **Port 5000** in read-only mode alongside the existing Java web application.

---

## 🚀 Key Features & Algorithms

### 1. Study Partner Recommendation (K-Means Clustering)
- **Algorithm:** K-Means unsupervised clustering combined with Cosine Similarity vector ranking.
- **Features Analyzed:** Student academic department, technical skills, and research/project interests.
- **Dynamic K Safeguard:** Automatically adjusts $K = \max(1, \min(3, N // 2))$ based on sample size $N$ so small college cohorts never crash.
- **Peer Matching:** Ranks potential study and project partners within the student's assigned cluster and calculates compatibility percentages.

### 2. Event Recommendation (TF-IDF + Cosine Similarity)
- **Algorithm:** Term Frequency - Inverse Document Frequency (TF-IDF) & Cosine Similarity vector space modeling.
- **Matching Logic:** Vectorizes student profile text against campus event descriptions, venues, and target departments.
- **Output:** Ranks upcoming hackathons, tech workshops, and symposiums by personalized relevance fit score.

### 3. Lost & Found Matching (TF-IDF Similarity Matcher)
- **Algorithm:** Pairwise TF-IDF Vectorization and Cosine Similarity.
- **Automated Pairing:** Scans active LOST and FOUND reports in the college and surfaces high-confidence matches ($\ge 25\%$).
- **Interactive Search:** Allows students to describe missing possessions in natural language and instantly searches matching recovered inventory.

### 4. Administrator Exploratory Data Analysis (Pandas + Chart.js)
- **Algorithm & Library:** Pandas data aggregation, frequency distributions, and Chart.js visualizations.
- **Insights Provided:**
  - Student enrollment distribution by academic department and study year.
  - Frequency distribution of top technical skills and student interests.
  - Grievance resolution metrics and category breakdown.
  - Lost versus found item ratios and recovery statistics.
  - Cluster membership inspection for college cohorts.

---

## 🔒 Security & Multi-College Isolation

- **Read-Only Database Account:** Connects exclusively via dedicated MySQL account `campus_ds_user` (`SELECT` permissions only). Zero risk of accidental schema or data mutation.
- **Multi-Tenant College Isolation:** Every recommendation, match, and analytical aggregation is strictly scoped to `college_id`.
- **Server-Side Role Guard:** Students cannot view the Admin Data Analysis tab. Any unauthorized request to `/admin/*` is rejected with **HTTP 403 Forbidden**.
- **Shared Authentication:** Uses SHA-256 password hashing matching the existing Java backend against the centralized `users` table.

---

## 🛠️ How to Open and Run in VS Code

### Step 1: Open in VS Code
Open VS Code and choose **File ➔ Open Folder...**, then select:
`C:\Users\dhiraj12\Desktop\CampusConnect_DS`

### Step 2: Open Terminal in VS Code
Open the integrated terminal in VS Code (`Ctrl + ~` or **Terminal ➔ New Terminal**).

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run Application
```bash
python app.py
```

### Step 5: Access the Web Portal
Open your web browser and navigate to:
**http://localhost:5000**

---

## 👥 Demo Login Credentials

| Role | College | Email | Password |
| :--- | :--- | :--- | :--- |
| **Student** | MCOE (Pune) | `rahul@ait.edu` | `student123` |
| **Student** | MCOE (Pune) | `priya@ait.edu` | `student123` |
| **Admin** | MCOE (Pune) | `admin@mcoe.edu.in` | `admin123` |
| **Admin** | Ferguson College | `admin@fc.edu.in` | `admin123` |
| **Admin** | VIT (Pune) | `admin@vit.edu.in` | `admin123` |

---

## 📁 Directory Structure
```
CampusConnect_DS/
├── .env                       # Environment configuration (read-only DB credentials)
├── requirements.txt           # Python dependencies (Flask, scikit-learn, pandas, pymysql)
├── config.py                  # Application configuration loader
├── database.py                # Read-only database query execution helper
├── auth.py                    # SHA-256 authentication & role decorators
├── partner_recommendation.py  # K-Means Study Partner Recommendation engine
├── event_recommendation.py    # TF-IDF Event Recommendation engine
├── lost_found_matching.py     # TF-IDF Lost & Found Matching engine
├── data_analysis.py           # Pandas EDA analytics & Chart.js data formatting
├── app.py                     # Flask web server and routing
├── templates/                 # Jinja2 HTML templates
│   ├── base.html              # Shared responsive navigation and layout
│   ├── login.html             # Secure login screen
│   ├── student_dashboard.html # Student portal overview
│   ├── partner.html           # Study Partner K-Means recommendation page
│   ├── events.html            # Event TF-IDF recommendation page
│   ├── lost_found.html        # Lost & Found similarity search & match page
│   ├── admin_dashboard.html   # Admin portal overview
│   ├── data_analysis.html     # Interactive Chart.js EDA dashboard
│   ├── admin_partners.html    # Admin student cluster inspection
│   └── admin_lost_found.html  # Admin lost & found matching report
└── static/
    ├── css/style.css          # CampusConnect styling theme
    └── js/main.js             # UI helpers
```
