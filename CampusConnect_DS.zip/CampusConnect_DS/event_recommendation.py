from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from database import query_db

def parse_items(text):
    if not text:
        return []
    return [item.strip() for item in str(text).split(",") if item.strip()]

def is_department_match(student_dept, event_dept):
    if not student_dept or not event_dept:
        return False
    s = student_dept.strip().lower()
    e = event_dept.strip().lower()
    if e in ["all", "all departments", "alln", "open for all"]:
        return True
    if s == e or s in e or e in s:
        return True
    aliases = {
        "mca": ["master of computer applications", "mca"],
        "master of computer applications": ["mca", "master of computer applications"],
        "cse": ["computer science", "computer engineering", "computer science and engineering", "cse"],
        "computer science": ["computer engineering", "cse", "computer science and engineering"],
        "it": ["information technology", "it"],
        "information technology": ["it", "information technology"]
    }
    for alias_key, alias_list in aliases.items():
        if alias_key in s:
            if any(a in e for a in alias_list):
                return True
    return False

def get_event_reasons(user, event, matched_interests=None):
    reasons = []
    text_content = f"{event.get('title') or ''} {event.get('description') or ''}".lower()
    user_dept = user.get("department") or ""
    event_dept = event.get("department") or ""

    # 1. Highest priority: Selected Interests from My Profile
    if matched_interests:
        reasons.append(f"Matches your selected interest in {', '.join(matched_interests[:2])}")
    else:
        for interest in parse_items(user.get("interests")):
            if interest.lower() in text_content:
                reasons.append(f"Matches your selected interest in {interest}")
                break

    # 2. Department Relevance
    if is_department_match(user_dept, event_dept):
        if (event_dept or "").strip().lower() in ["all", "all departments", "alln", "open for all"]:
            reasons.append("Open to all campus departments")
        else:
            reasons.append(f"Relevant to your department ({event_dept})")

    # 3. Technical Skills Overlap
    for skill in parse_items(user.get("skills")):
        if skill.lower() in text_content:
            reasons.append(f"Matches your skill in {skill}")
            break

    if not reasons:
        reasons.append("Campus event open to students")

    return reasons[:3]

def recommend_events(college_id, user_id, dept_filter=None, keyword_filter=None):
    user = query_db(
        "SELECT id, department, skills, interests FROM users WHERE id = %s",
        (user_id,),
        one=True
    )
    events = query_db(
        """SELECT id, college_id, title, description, venue, event_date, registration_link, department 
           FROM events 
           WHERE college_id = %s 
           ORDER BY event_date ASC""",
        (college_id,)
    )

    if not events:
        return {"events": [], "departments": []}

    all_departments = sorted(list({e["department"] for e in events if e.get("department")}))

    user_interests = parse_items(user.get("interests")) if user else []
    user_dept = (user.get("department") or "").strip() if user else ""

    event_texts = [
        f"{e.get('title') or ''} {e.get('description') or ''} {e.get('venue') or ''}".strip().lower() or "event"
        for e in events
    ]

    # TF-IDF cosine similarity for selected interests
    interest_sim_scores = [0.0] * len(events)
    if user_interests:
        interest_query = " ".join(user_interests).lower()
        vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
        try:
            tfidf_matrix = vectorizer.fit_transform([interest_query] + event_texts)
            interest_sim_scores = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1:]).flatten()
        except Exception:
            interest_sim_scores = [0.0] * len(events)

    results = []
    for i, e in enumerate(events):
        if dept_filter and e.get("department") != dept_filter:
            continue
        if keyword_filter:
            combined = f"{e.get('title') or ''} {e.get('description') or ''}".lower()
            if keyword_filter.lower() not in combined:
                continue

        event_text = event_texts[i]
        event_dept = e.get("department") or ""

        # 1. Identify which selected interests matched
        matched_interests = []
        for interest in user_interests:
            int_lower = interest.lower().strip()
            # check token / substring overlap
            if int_lower in event_text or any(token in event_text for token in int_lower.split() if len(token) > 2):
                matched_interests.append(interest)

        has_interest_match = bool(matched_interests) or (interest_sim_scores[i] > 0.08)
        interest_tfidf = float(interest_sim_scores[i])

        # 2. Check department match
        dept_matched = is_department_match(user_dept, event_dept)
        is_all_dept = (event_dept.strip().lower() in ["all", "all departments", "alln", "open for all"])

        # 3. Calculate Prioritized Score:
        # Give HIGHER priority to events that match student's selected interests
        if has_interest_match:
            # High priority tier: 70% to 98%
            base_score = 0.65 + (0.25 * interest_tfidf)
            if dept_matched and not is_all_dept:
                base_score += 0.08
            elif is_all_dept:
                base_score += 0.04
            final_percent = min(98, max(70, round(base_score * 100)))
            rank_score = base_score + 1.0  # guarantees ranking above department-only events
        elif dept_matched and not is_all_dept:
            # Medium priority tier: department match without specific interest match
            final_percent = min(55, max(38, 42))
            rank_score = 0.42
        elif is_all_dept:
            # Open for all campus students
            final_percent = 25
            rank_score = 0.25
        else:
            # Different department, no interest match
            final_percent = 15
            rank_score = 0.15

        reasons = get_event_reasons(user, e, matched_interests) if user else ["Campus event"]

        date_str = e["event_date"].strftime("%b %d, %Y - %I:%M %p") if hasattr(e["event_date"], "strftime") else str(e["event_date"])

        results.append({
            "id": e["id"],
            "title": e["title"],
            "description": e["description"] or "No detailed description provided.",
            "venue": e["venue"] or "Campus",
            "department": e["department"] or "All Departments",
            "event_date": date_str,
            "registration_link": e["registration_link"],
            "has_interest_match": has_interest_match,
            "similarity_percent": final_percent,
            "reasons": reasons,
            "similarity_score": round(rank_score, 4)
        })

    # Sort strictly by priority score (interest matches always at top)
    results.sort(key=lambda x: x["similarity_score"], reverse=True)

    return {
        "events": results,
        "departments": all_departments
    }
