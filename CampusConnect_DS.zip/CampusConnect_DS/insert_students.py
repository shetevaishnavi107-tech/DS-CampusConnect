﻿import json
import hashlib
import pymysql

PASSWORD_HASH = hashlib.sha256("student123".encode("utf-8")).hexdigest()

with open("students_data.json", "r", encoding="utf-8") as f:
    colleges_data = json.load(f)

conn = pymysql.connect(
    host="localhost",
    port=3306,
    user="root",
    password="Admin@123",
    database="campus_connect_db",
    charset="utf8mb4",
    autocommit=False
)
cur = conn.cursor()

# Get existing emails
cur.execute("SELECT email FROM users")
existing_emails = {row[0].lower() for row in cur.fetchall()}

insert_sql = """
    INSERT INTO users (
        college_id, full_name, email, password_hash, role,
        department, roll_no, semester, year, phone,
        bio, skills, interests, is_verified
    ) VALUES (
        %s, %s, %s, %s, 'STUDENT',
        %s, %s, %s, %s, %s,
        %s, %s, %s, 1
    )
"""

total_inserted = 0

for college_id_str, students in colleges_data.items():
    college_id = int(college_id_str)
    c_inserted = 0
    for s in students:
        full_name, email, department, year, semester, roll_no, phone, skills, interests, bio = s
        if email.lower() in existing_emails:
            continue

        cur.execute(insert_sql, (
            college_id, full_name, email, PASSWORD_HASH,
            department, roll_no, semester, year, phone,
            bio, skills, interests
        ))
        existing_emails.add(email.lower())
        c_inserted += 1
        total_inserted += 1

    print(f"College {college_id}: Inserted {c_inserted} new students.")

conn.commit()

# Print summary
cur.execute("""
    SELECT c.id, c.code, c.name, COUNT(u.id) as student_count
    FROM colleges c
    LEFT JOIN users u ON u.college_id = c.id AND u.role = 'STUDENT'
    GROUP BY c.id, c.code, c.name
    ORDER BY c.id
""")
print("\nFinal Student Counts per College:")
for row in cur.fetchall():
    print(f"  College {row[0]} ({row[1]} - {row[2]}): {row[3]} students")

conn.close()
