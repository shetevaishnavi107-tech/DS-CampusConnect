import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from database import query_db

def tokenize(text):
    if not text:
        return set()
    words = re.findall(r"\b[a-zA-Z0-9]{3,}\b", text.lower())
    stop_words = {"the", "and", "for", "with", "this", "that", "was", "from", "left", "found", "lost"}
    return {w for w in words if w not in stop_words}

def get_match_reasons(lost, found):
    reasons = []

    # Name token overlap
    l_name_words = tokenize(lost.get("item_name"))
    f_name_words = tokenize(found.get("item_name"))
    common_name = l_name_words & f_name_words
    if common_name:
        reasons.append(f"Similar item name ({', '.join(list(common_name)[:2])})")

    # Description token overlap
    l_desc_words = tokenize(lost.get("description"))
    f_desc_words = tokenize(found.get("description"))
    common_desc = l_desc_words & f_desc_words
    if common_desc:
        reasons.append("Similar item description")

    # Location overlap
    l_loc = (lost.get("location") or "").lower()
    f_loc = (found.get("location") or "").lower()
    l_loc_words = tokenize(l_loc)
    f_loc_words = tokenize(f_loc)
    if l_loc and f_loc and (l_loc in f_loc or f_loc in l_loc or (l_loc_words & f_loc_words)):
        reasons.append("Similar campus location")

    if not reasons:
        reasons.append("General keyword resemblance")

    return reasons

def text_representation(item):
    name = item.get("item_name") or ""
    desc = item.get("description") or ""
    loc = item.get("location") or ""
    return f"{name} {desc} {loc}".strip() or "item"

def match_lost_and_found(college_id, user_id=None, threshold=0.20):
    items = query_db(
        """SELECT id, college_id, user_id, type, item_name, description, location, 
                  item_date, image_url, contact_phone, contact_email, status, created_at 
           FROM lost_found 
           WHERE college_id = %s 
           ORDER BY created_at DESC""",
        (college_id,)
    )

    lost_items = [i for i in items if (i["type"] or "").upper() == "LOST"]
    found_items = [i for i in items if (i["type"] or "").upper() == "FOUND"]

    if not lost_items or not found_items:
        return {
            "matched_pairs": [],
            "lost_count": len(lost_items),
            "found_count": len(found_items),
            "total_items": len(items)
        }

    lost_texts = [text_representation(i) for i in lost_items]
    found_texts = [text_representation(i) for i in found_items]

    vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
    vectorizer.fit(lost_texts + found_texts)

    lost_matrix = vectorizer.transform(lost_texts)
    found_matrix = vectorizer.transform(found_texts)

    sim_matrix = cosine_similarity(lost_matrix, found_matrix)

    matched_pairs = []
    for l_idx, l_item in enumerate(lost_items):
        for f_idx, f_item in enumerate(found_items):
            score = float(sim_matrix[l_idx, f_idx])
            if score >= threshold:
                reasons = get_match_reasons(l_item, f_item)
                matched_pairs.append({
                    "lost_id": l_item["id"],
                    "lost_owner_id": l_item["user_id"],
                    "lost_name": l_item["item_name"],
                    "lost_desc": l_item["description"] or "No description",
                    "lost_loc": l_item["location"] or "Unknown",
                    "lost_status": l_item["status"],
                    "lost_image_url": l_item.get("image_url"),
                    "lost_contact": l_item["contact_phone"] or l_item["contact_email"] or "N/A",
                    "found_id": f_item["id"],
                    "found_owner_id": f_item["user_id"],
                    "found_name": f_item["item_name"],
                    "found_desc": f_item["description"] or "No description",
                    "found_loc": f_item["location"] or "Unknown",
                    "found_status": f_item["status"],
                    "found_image_url": f_item.get("image_url"),
                    "found_contact": f_item["contact_phone"] or f_item["contact_email"] or "N/A",
                    "similarity_score": round(score, 4),
                    "match_percent": round(score * 100),
                    "confidence": "High" if score >= 0.50 else ("Moderate" if score >= 0.30 else "Fair"),
                    "reasons": reasons
                })

    matched_pairs.sort(key=lambda x: x["similarity_score"], reverse=True)

    # Privacy rule: Only show matches involving the logged-in student
    if user_id is not None:
        matched_pairs = [
            m for m in matched_pairs 
            if m["lost_owner_id"] == user_id or m["found_owner_id"] == user_id
        ]

    return {
        "matched_pairs": matched_pairs,
        "lost_count": len(lost_items),
        "found_count": len(found_items),
        "total_items": len(items)
    }

def search_matching_items(college_id, query_text, target_type="FOUND"):
    items = query_db(
        """SELECT id, college_id, user_id, type, item_name, description, location, 
                  item_date, image_url, contact_phone, contact_email, status, created_at 
           FROM lost_found 
           WHERE college_id = %s AND UPPER(type) = %s 
           ORDER BY created_at DESC""",
        (college_id, target_type.upper())
    )

    if not items or not query_text or not query_text.strip():
        return []

    item_texts = [text_representation(i) for i in items]
    vectorizer = TfidfVectorizer(stop_words="english", min_df=1)
    all_texts = [query_text.strip()] + item_texts
    matrix = vectorizer.fit_transform(all_texts)

    query_vec = matrix[0]
    target_vecs = matrix[1:]

    sim_scores = cosine_similarity(query_vec, target_vecs).flatten()

    dummy_query_item = {"item_name": query_text, "description": query_text, "location": ""}

    matches = []
    for i, item in enumerate(items):
        score = float(sim_scores[i])
        reasons = get_match_reasons(dummy_query_item, item)
        matches.append({
            "id": item["id"],
            "owner_id": item["user_id"],
            "type": item["type"],
            "item_name": item["item_name"],
            "description": item["description"] or "No description",
            "location": item["location"] or "Unknown",
            "image_url": item.get("image_url"),
            "status": item["status"],
            "contact": item["contact_phone"] or item["contact_email"] or "N/A",
            "similarity_score": round(score, 4),
            "match_percent": round(score * 100),
            "reasons": reasons
        })

    matches.sort(key=lambda x: x["similarity_score"], reverse=True)
    return matches
